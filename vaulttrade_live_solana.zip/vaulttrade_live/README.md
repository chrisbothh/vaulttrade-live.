# VaultTrade Live — Solana Scanner

## Open
Extract the ZIP and open `index.html` in a browser. The live scanner needs an internet connection. If the Files preview blocks network requests, publish the folder as a static website (for example, GitHub Pages or another static host), then open the hosted HTTPS URL.

## What this version does
- Fetches latest public Solana token profiles from DEX Screener.
- Looks up matching market pairs and displays live snapshot price, liquidity, 24h volume, and a basic heuristic screen score.
- Filters and sorts tokens.
- Copies a token contract address so you can search it in Fomo.
- Includes a read-only Phantom connect button for a hosted site opened inside Phantom's in-app browser.
- Keeps paper buys separate from real trading.

## Important limitations
- The score is a simple heuristic, not an AI model, audit, rug-pull guarantee, or buy recommendation.
- DEX Screener profile listings are not a complete feed of every new launch.
- This page does not place trades, sign transactions, custody funds, or connect to Fomo's private trading systems.
- Fomo is a separate self-custodial trading app; use its own interface and review every quote before confirming.
- Never enter a recovery phrase or private key into this site. Never approve transactions you do not understand.

## Data/API
Uses public DEX Screener API endpoints:
- https://api.dexscreener.com/token-profiles/latest/v1
- https://api.dexscreener.com/tokens/v1/solana/{tokenAddresses}

## Next production steps
Host on HTTPS, add stronger token safety checks from independent sources, test API limits and CORS behavior, then consider wallet transaction integration with explicit user approval and strict spend/slippage limits. A production trading service requires a reviewed backend and security audit.
